var slider = $('#slider');
var track = slider.find('.track');
var modnum = slider.find('.thumb').length;
var modwidth = slider.find('.thumb').eq(0).outerWidth();
var trackwidth = slider.find('.slider-container').outerWidth();
var overflow = modnum * modwidth - trackwidth;

track.width(modnum * modwidth);

if (modnum > 4) {
    $('.btnPrev').show();
    $('.btnNext').show();
}

$('.btnPrev').click(function () {
    var left = parseInt(track.css("marginLeft"), 10);
    track.queue("steps", function (next) {

        if (left >= 0) {
            track.animate({
                marginLeft: '+=50px'
            }, 130);
        } else {
            track.animate({
                marginLeft: '+=160px'
            }, 260);
        }
        next();

    }).queue("steps", function (next) {

        if (left >= 0) {
            track.animate({
                marginLeft: 0
            }, 130);
        }
        next();

    }).dequeue("steps");
});

$('.btnNext').click(function () {
    var left = parseInt(track.css("marginLeft"), 10);
    track.queue("steps", function (next) {

        if (Math.abs(left) >= overflow - modwidth) {
            track.animate({
                marginLeft: '-=50px'
            }, 130);
        } else {
            track.animate({
                marginLeft: '-=160px'
            }, 260);
        }
        next();

    }).queue("steps", function (next) {

        if (Math.abs(left) >= overflow - modwidth) {
            track.animate({
                marginLeft: -overflow
            }, 130);
        }
        next();

    }).dequeue("steps");
});